import streamlit as st

st.set_page_config(page_title="Fake News Detection App", layout="wide")
st.title("📰 Fake News Detection – Proyecto NLP")

st.sidebar.title("Navegación")
st.sidebar.info("Selecciona una página desde el menú.")