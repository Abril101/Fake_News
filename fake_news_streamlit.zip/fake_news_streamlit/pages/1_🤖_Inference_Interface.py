import streamlit as st
from utils.inference import get_predictions

st.title("🤖 Página 1 – Interfaz de Inferencia")
st.write("Introduce un texto o par de textos para clasificar si es Fake News o Real.")

text1 = st.text_area("Texto principal (título o contenido)", height=150)
text2 = st.text_area("Texto secundario (opcional)", height=100)

if st.button("🔍 Predecir"):
    if text1.strip():
        results = get_predictions(text1, text2)
        st.subheader("🧠 Resultados de los Modelos")
        for model, (label, confidence) in results.items():
            st.markdown(f"**{model}** → Predicción: `{label}` | Confianza: `{confidence:.2f}`")
    else:
        st.warning("Por favor escribe al menos un texto.")